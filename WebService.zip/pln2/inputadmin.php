<?php
include 'koneksi.php';
$response=array();




$kode_trafo=$_POST['kode_trafo'];
$feeder=$_POST['feeder'];
$lokasi=$_POST['lokasi'];
$daya=$_POST['daya'];



$result=mysql_query("INSERT INTO tbl_trafo(kode_trafo,feeder,lokasi,daya)
VALUES('$kode_trafo','$feeder','$lokasi','$daya')");
echo $result;
if ($result >0){
$response["sukses"]=1;

}else{
$response["sukses"]=0;
}
echo json_encode($response);


?>
