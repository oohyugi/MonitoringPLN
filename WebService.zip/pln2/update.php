<?php
include 'koneksi.php';
$response=array();


   $idpengukuran=$_GET['idpengukuran'];


$indukR=$_GET['induk_R'];
$indukS=$_GET['induk_S'];
$indukT=$_GET['induk_T'];
$indukN=$_GET['induk_N'];
$blok1_R=$_GET['blok1_R'];
$blok1_S=$_GET['blok1_S'];
$blok1_T=$_GET['blok1_T'];
$blok1_N=$_GET['blok1_N'];

$blok2_R=$_GET['blok2_R'];
$blok2_S=$_GET['blok2_S'];
$blok2_T=$_GET['blok2_T'];
$blok2_N=$_GET['blok2_N'];

$blok3_R=$_GET['blok3_R'];
$blok3_S=$_GET['blok3_S'];
$blok3_T=$_GET['blok3_T'];
$blok3_N=$_GET['blok3_N'];

$persen_beban=$_GET['persen_beban'];

    $result = mysql_query("update tbl_pengukuran set induk_R='$indukR',induk_S='$indukS',induk_T='$indukT',induk_N='$indukN',blok1_R='$blok1_R',blok1_S='$blok1_S',blok1_T='$blok1_T',blok1_N='$blok1_N',blok2_R='$blok2_R',blok2_S='$blok2_S',blok2_T='$blok2_T',blok2_N='$blok2_N',blok3_R='$blok3_R',blok3_S='$blok3_S',blok3_T='$blok3_T',blok3_N='$blok3_N',persen_beban='$persen_beban' where idpengukuran='$idpengukuran' ") or die(mysql_error());

    $row_count = mysql_affected_rows();

    if($row_count>0){
         $response["sukses"] = 4;
         $response["message"] = "Updated Sucessfully.";
     }
    else{
        $response["sukses"] = 0;
        $response["message"] = "Failed To Update.";  
     }  
  // echoing JSON response
  echo json_encode($response);

?>