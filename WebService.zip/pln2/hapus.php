<?php

include 'koneksi.php';
$response=array();

if(isset($_GET['idpengukuran'])){
$idtrafo=$_GET['idpengukuran'];

$hasil= mysql_query("DELETE FROM tbl_pengukuran where idpengukuran='$idtrafo'");
$row_count= mysql_affected_rows();

if($row_count>0){
$response["sukses"]=4;
$response["pesan"]="delete sukses";
}else{

 $response["sukses"] = 0;
        $response["pesan"] = "Failed To Delete"; 
}
echo json_encode($response);
}
?>
