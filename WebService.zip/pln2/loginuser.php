<?php
/**
* 
*/
include 'koneksi.php';
$response=array();

    
$username = $_GET['username'];

$password = $_GET['password'];
	$status= $_GET['status'];
	


//ambil semua data
$hasil1= mysql_query("SELECT * from tbl_user where username='$username' and password='$password' and status='$status'")or die(mysql_error());
if (mysql_num_rows($hasil1)>0) {
	$response["login"]=array();
	
   
	while ($rows= mysql_fetch_array($hasil1)) {
		$items=array();
		
		
		
		$items["id_user"]=$rows["id_user"];
		$items["username"]=$rows["username"];
		$items["password"]=$rows["password"];
$items["status"]=$rows["status"];
		

		array_push($response["login"], $items);

	}

	$response["sukses"] =4;

	echo json_encode($response);
}
	
	else{
		$response["sukses"] =0;
		$response["pesan"] ="No Items Found";

	}
	
?>
