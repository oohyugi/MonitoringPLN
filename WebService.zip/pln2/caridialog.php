<?php
/**
* 
*/
include 'koneksi.php';
$response=array();

    

	$kode_trafo=$_GET["kode_trafo"];


//ambil semua data
$hasil1= mysql_query("SELECT * From tbl_trafo where kode_trafo LIKE '%$kode_trafo%'")or die(mysql_error());
if (mysql_num_rows($hasil1)>0) {
	$response["data"]=array();
	
   
	while ($rows= mysql_fetch_array($hasil1)) {
		$items=array();
		
		
		
		$items["id_trafo"]=$rows["id_trafo"];
		$items["feeder"]=$rows["feeder"];
		$items["daya"]=$rows["daya"];
$items["lokasi"]=$rows["lokasi"];

$items["kode_trafo"]=$rows["kode_trafo"];

		

		array_push($response["data"], $items);

	}

	$response["sukses"] =4;

	echo json_encode($response);
}
	
	else{
		$response["sukses"] =0;
		$response["pesan"] ="No Items Found";

	}
	
?>
