<?php
include 'koneksi.php';
$response=array();




$id_trafo=$_POST['id_trafo'];
$indukR=$_POST['induk_R'];
$indukS=$_POST['induk_S'];
$indukT=$_POST['induk_T'];
$indukN=$_POST['induk_N'];
$blok1_R=$_POST['blok1_R'];
$blok1_S=$_POST['blok1_S'];
$blok1_T=$_POST['blok1_T'];
$blok1_N=$_POST['blok1_N'];

$blok2_R=$_POST['blok2_R'];
$blok2_S=$_POST['blok2_S'];
$blok2_T=$_POST['blok2_T'];
$blok2_N=$_POST['blok2_N'];

$blok3_R=$_POST['blok3_R'];
$blok3_S=$_POST['blok3_S'];
$blok3_T=$_POST['blok3_T'];
$blok3_N=$_POST['blok3_N'];

$persen_beban=$_POST['persen_beban'];
$result=mysql_query("INSERT INTO tbl_pengukuran(id_trafo,induk_R,induk_S,induk_T,induk_N,blok1_R,blok1_S,blok1_T,blok1_N,blok2_R,blok2_S,blok2_T,blok2_N,blok3_R,blok3_S,blok3_T,blok3_N,persen_beban)
VALUES('$id_trafo','$indukR','$indukS','$indukT','$indukN','$blok1_R','$blok1_S','$blok1_T','$blok1_N','$blok2_R','$blok2_S','$blok2_T','$blok2_N','$blok3_R','$blok3_S','$blok3_T','$blok3_N','$persen_beban')");
if ($result >0){
$response["sukses"]=1;

}else{
$response["sukses"]=0;
}
echo json_encode($response);


?>
