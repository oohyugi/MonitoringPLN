-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 18, 2015 at 09:24 
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pln2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengukuran`
--

CREATE TABLE IF NOT EXISTS `tbl_pengukuran` (
  `idpengukuran` int(10) NOT NULL,
  `tgl_pengukuran` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jam_pengukuran` varchar(15) NOT NULL,
  `induk_R` double NOT NULL,
  `induk_S` double NOT NULL,
  `induk_T` double NOT NULL,
  `induk_N` double NOT NULL,
  `blok1_R` double NOT NULL,
  `blok1_S` double NOT NULL,
  `blok1_T` double NOT NULL,
  `blok1_N` double NOT NULL,
  `blok2_R` double NOT NULL,
  `blok2_S` double NOT NULL,
  `blok2_T` double NOT NULL,
  `blok2_N` double NOT NULL,
  `blok3_R` double NOT NULL,
  `blok3_S` double NOT NULL,
  `blok3_T` double NOT NULL,
  `blok3_N` double NOT NULL,
  `persen_beban` double NOT NULL,
  `id_trafo` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengukuran`
--

INSERT INTO `tbl_pengukuran` (`idpengukuran`, `tgl_pengukuran`, `jam_pengukuran`, `induk_R`, `induk_S`, `induk_T`, `induk_N`, `blok1_R`, `blok1_S`, `blok1_T`, `blok1_N`, `blok2_R`, `blok2_S`, `blok2_T`, `blok2_N`, `blok3_R`, `blok3_S`, `blok3_T`, `blok3_N`, `persen_beban`, `id_trafo`) VALUES
(3, '2015-09-18 19:15:31', '00:00', 11, 11, 11, 11, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4.76, 1),
(5, '2015-09-18 19:15:39', '00:00', 33, 33, 33, 33, 33, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 14.27, 1),
(6, '2015-09-18 19:15:59', '', 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 4.68, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trafo`
--

CREATE TABLE IF NOT EXISTS `tbl_trafo` (
  `id_trafo` int(10) NOT NULL,
  `kode_trafo` varchar(30) NOT NULL,
  `feeder` varchar(30) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `daya` double NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_trafo`
--

INSERT INTO `tbl_trafo` (`id_trafo`, `kode_trafo`, `feeder`, `lokasi`, `daya`) VALUES
(1, 'AA015JAZ0239T', 'Polamas', 'JL. AZIZI', 100),
(2, 'AB013STR0204T', 'Anduring', 'Jl. SURAU TARANTANG', 160),
(3, 'XXYZ', 'Kerinci', 'Kerinci', 340),
(5, 'AA015JGT0238T', 'Polamas', 'Jl. Garuda Tepi Bandar Bakali', 100),
(6, 'AB013STR0204T', 'Anduring', 'Jl. SURAU TARANTANG', 160),
(7, 'AB013STS0203T', 'Anduring', 'Jl. SURAU TARANTANG', 160),
(8, 'AB041AZK0140T', 'KOTO TINGGA', 'ADZKIA PEMAKAIAN KHUSUSG', 100);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id_user` int(3) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `status`) VALUES
(1, 'admin', 'admin', 'admin'),
(2, 'user', 'user', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_pengukuran`
--
ALTER TABLE `tbl_pengukuran`
  ADD PRIMARY KEY (`idpengukuran`);

--
-- Indexes for table `tbl_trafo`
--
ALTER TABLE `tbl_trafo`
  ADD PRIMARY KEY (`id_trafo`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_pengukuran`
--
ALTER TABLE `tbl_pengukuran`
  MODIFY `idpengukuran` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_trafo`
--
ALTER TABLE `tbl_trafo`
  MODIFY `id_trafo` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
