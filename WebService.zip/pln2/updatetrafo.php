<?php
include 'koneksi.php';
$response=array();


   


$id_trafo=$_GET['id_trafo'];
$kode_trafo=$_GET['kode_trafo'];
$feeder=$_GET['feeder'];
$lokasi=$_GET['lokasi'];
$daya=$_GET['daya'];


    $result = mysql_query("update tbl_trafo set kode_trafo='$kode_trafo',feeder='$feeder',lokasi='$lokasi',daya='$daya' where id_trafo='$id_trafo' ") or die(mysql_error());

    $row_count = mysql_affected_rows();

    if($row_count>0){
         $response["sukses"] = 4;
         $response["message"] = "Updated Sucessfully.";
     }
    else{
        $response["sukses"] = 0;
        $response["message"] = "Failed To Update.";  
     }  
  // echoing JSON response
  echo json_encode($response);

?>