<?php
/**
* 
*/
include 'koneksi.php';
$response=array();

    

$feeder=$_GET['feeder'];	


//ambil semua data
$hasil1= mysql_query("SELECT tbl_trafo.*,tbl_pengukuran.* from tbl_trafo,tbl_pengukuran where tbl_trafo.id_trafo=tbl_pengukuran.id_trafo AND tbl_trafo.feeder LIKE '$feeder%'")or die(mysql_error());
if (mysql_num_rows($hasil1)>0) {
	$response["data"]=array();
	
   
	while ($rows= mysql_fetch_array($hasil1)) {
		$items=array();
		
		
		
		$items["id_trafo"]=$rows["id_trafo"];
		$items["feeder"]=$rows["feeder"];
		$items["daya"]=$rows["daya"];
$items["lokasi"]=$rows["lokasi"];
$items["persen_beban"]=$rows["persen_beban"];
$items["kode_trafo"]=$rows["kode_trafo"];
$items["idpengukuran"]=$rows["idpengukuran"];
$items["tgl_pengukuran"]=$rows["tgl_pengukuran"];
$items["induk_R"]=$rows["induk_R"];
		$items["induk_S"]=$rows["induk_S"];
		$items["induk_T"]=$rows["induk_T"];
		$items["induk_N"]=$rows["induk_N"];
		$items["blok1_R"]=$rows["blok1_R"];
		$items["blok1_S"]=$rows["blok1_S"];
		$items["blok1_T"]=$rows["blok1_T"];
		$items["blok1_N"]=$rows["blok1_N"];
		$items["blok2_R"]=$rows["blok2_R"];
		$items["blok2_S"]=$rows["blok2_S"];
		$items["blok2_T"]=$rows["blok2_T"];
		$items["blok2_N"]=$rows["blok2_N"];
		$items["blok3_R"]=$rows["blok3_R"];
		$items["blok3_S"]=$rows["blok3_S"];
		$items["blok3_T"]=$rows["blok3_T"];
		$items["blok3_N"]=$rows["blok3_N"];
		

		array_push($response["data"], $items);

	}

	$response["sukses"] =4;

	echo json_encode($response);
}
	
	else{
		$response["sukses"] =0;
		$response["pesan"] ="No Items Found";

	}
	
?>
